# -*- coding: utf-8 -*- #
import pythoncom
import pyHook
import win32api,win32gui,win32con


windows = []
# 问题1:这个startSync我只想类似于标识一样 不需要定义成数组 但是用startSync = 0的话执行会报错 为啥定义成数组就不报错了
startSync = []


def onKeyboardEvent(event):
    # F6将当前窗口加入同步
    if event.KeyID == 117:
        hwnd = win32gui.GetForegroundWindow()
        windows.append(hwnd)
        txt = win32gui.GetWindowText(hwnd)
        print hwnd, 'append to windows, title:', txt

    # 发送按键到其他窗口
    if len(startSync) != 0:
        windows_max = len(windows)
        for index in range(windows_max):
            # 第一个加入的窗口未主窗口 无需同步按键
            # if index == 0:
            #     continue

            # 问题2：这种方法可以发送按键 但是有个问题 会无限循环 这个keybd_event又触发了键盘事件
            # win32gui.SetForegroundWindow(windows[index])
            # win32api.keybd_event(event.KeyID, 0, 0, 0)
            # win32api.keybd_event(event.KeyID, 0, win32con.KEYEVENTF_KEYUP, 0)  # 释放按键

            # 问题3：这种方法貌似不能发送按键到未激活的窗口 即使上面setForeground了下 还有个问题 只能发送按键到最后个窗口
            res = win32gui.PostMessage(windows[index], win32con.WM_KEYDOWN, event.KeyID, 0)
            res2 = win32gui.PostMessage(windows[index], win32con.WM_KEYUP, event.KeyID, 0)
            print res, '|', res2

        for index in range(windows_max):
            win32gui.GetMessage()

    # F7开始同步
    if event.KeyID == 118:
        startSync.append(1)
        print 'start sync'

    return True


def main(): 
    # 创建一个“钩子”管理对象 
    hm = pyHook.HookManager()  
    # 监听所有键盘事件 
    hm.KeyDown = onKeyboardEvent 
    # 设置键盘“钩子” 
    hm.HookKeyboard()
    # 进入循环，如不手动关闭，程序将一直处于监听状态 
    pythoncom.PumpMessages()

    
if __name__ == "__main__": 
    main()
