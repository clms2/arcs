# -*- coding: utf-8 -*- #
import pythoncom
import pyHook
import win32api, win32gui, win32con

windows = []
# 问题1:这个startSync我只想类似于标识一样 不需要定义成数组 但是用startSync = 0的话执行会报错 为啥定义成数组就不报错了..
startSync = []


def onKeyboardEvent(event):
    # F6加入同步
    if event.KeyID == 117:
        hwnd = win32gui.GetForegroundWindow()
        windows.append(hwnd)

    # 发送按键到其他窗口
    if len(startSync) != 0:
        windows_max = len(windows)
        for index in range(windows_max):
            if index == 0:
                continue
            win32gui.SetForegroundWindow(windows[index])
            win32gui.PostMessage(windows[index], win32con.WM_KEYDOWN, event.KeyID, 0)
            win32gui.PostMessage(windows[index], win32con.WM_KEYUP, event.KeyID, 0)

            # win32gui.PostMessage(windows[index], win32con.WM_KEYDOWN, event.KeyID, 0)
            # win32gui.PostMessage(windows[index], win32con.WM_KEYUP, event.KeyID, 0)

            # 用这个keybd_event是可以发送按键 但是会一直循环。。
            # 获取窗口焦点
            # win32gui.SetForegroundWindow(windows[index])
            # win32api.keybd_event(event.KeyID, 0, 0, 0)
            # win32api.keybd_event(event.KeyID, 0, win32con.KEYEVENTF_KEYUP, 0)  # 释放按键
            # 下面这些都没法对位
            # win32gui.PostMessage(windows[index], win32con.WM_KEYDOWN, event.KeyID, 0)
            # win32gui.PostMessage(windows[index], win32con.WM_KEYUP, event.KeyID, 0)
            # win32gui.PostMessage(windows[index], win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)
            # win32gui.PostMessage(windows[index], win32con.WM_KEYUP, win32con.VK_RETURN, 0)
            # win32api.PostMessage(windows[index], win32con.WM_CHAR, event.KeyID, 0)
            # win32api.PostMessage(windows[index], win32con.WM_KEYUP, event.KeyID, 0)
            # print index

    # F7开始同步
    if event.KeyID == 118:
        startSync.append(1)

    print "Key:", event.Key
    print "KeyID:", event.KeyID
    # print "ScanCode:", event.ScanCode
    # print "Extended:", event.Extended
    # print "Injected:", event.Injected
    # print "Alt", event.Alt
    # print "Transition", event.Transition
    print "---"
    return True


def main():
    # 创建一个“钩子”管理对象
    hm = pyHook.HookManager()
    # 监听所有键盘事件
    hm.KeyDown = onKeyboardEvent
    # 设置键盘“钩子”
    hm.HookKeyboard()
    # 进入循环，如不手动关闭，程序将一直处于监听状态
    pythoncom.PumpMessages()


if __name__ == "__main__":
    main()
